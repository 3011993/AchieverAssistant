package com.example.achieverassistant.moments

import android.widget.EditText
import androidx.annotation.RequiresApi
import android.os.Build
import android.os.Bundle
import com.example.achieverassistant.R
import android.content.Intent
import android.media.ExifInterface
import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.achieverassistant.databinding.ActivityAddeditmomentBinding
import java.io.IOException
import java.text.SimpleDateFormat

class ADDEDITMoment : AppCompatActivity() {


    lateinit var file: String
    lateinit var dateString: String

    lateinit var binding : ActivityAddeditmomentBinding

    @RequiresApi(api = Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_addeditmoment)



        val data = intent
        if (data.hasExtra(Moments.EXTRA_PICTURE_PATH)) {
            title = "Add your Moment"
            file = data.getStringExtra(Moments.EXTRA_PICTURE_PATH).toString()
            ///date of the moment
            var intf: ExifInterface?
            try {
                intf = ExifInterface(file!!)
                if (intf != null) {
                    dateString = intf.getAttribute(ExifInterface.TAG_DATETIME).toString()
                    //Dispaly dateString. You can do/use it your own way
                    binding.edittextDateMoment.setText(dateString)
                }
            } catch (e: IOException) {

                e.printStackTrace()
            }

            val bitmap = BitmapFactory.decodeFile(data.getStringExtra(Moments.EXTRA_PICTURE_PATH))
            binding.imageviewMoment.setImageBitmap(bitmap)
        } else if (data.hasExtra(Moments.EXTRA_EDIT_PICTURE_PATH)){
            title = "Edit Your Moment"
            file = data.getStringExtra(Moments.EXTRA_EDIT_PICTURE_PATH).toString()
            ///date of the moment
            var intf: ExifInterface?
            try {
                intf = ExifInterface(file!!)
                if (intf != null) {
                    dateString = intf.getAttribute(ExifInterface.TAG_DATETIME).toString()
                    //Dispaly dateString. You can do/use it your own way
                    binding.edittextDateMoment.setText(dateString)
                }
            } catch (e: IOException) {

                e.printStackTrace()
            }

            val bitmap = BitmapFactory.decodeFile(data.getStringExtra(Moments.EXTRA_EDIT_PICTURE_PATH))
            binding.imageviewMoment.setImageBitmap(bitmap)
        }
        binding.setMoment.setOnClickListener {  recordMoment() }
    }


    private fun recordMoment() {
        val nameOfMoment = binding.edittextYourmomentName.text.toString()
        val dateOfMoment = binding.edittextDateMoment.text.toString()
        val shortDescription = binding.edittextShortDescription.text.toString()
        if (nameOfMoment.isEmpty()) {
            Toast.makeText(applicationContext, "Please Add your Moment name", Toast.LENGTH_SHORT)
                .show()
            return
        }
        val saveMomentIntent = Intent()
        saveMomentIntent.putExtra(EXTRA_DATA_IMAGE_MOMENT, file)
        saveMomentIntent.putExtra(EXTRA_DATA_TITLE, nameOfMoment)
        saveMomentIntent.putExtra(EXTRA_DATA_DATE, dateOfMoment)
        saveMomentIntent.putExtra(EXTRA_DATA_SHORT_DESCRIPTION_MOMENT, shortDescription)
        val id = intent.getIntExtra(EXTRA_DATA_ID_MOMENT, -1)
        if (id != -1) {
            saveMomentIntent.putExtra(EXTRA_DATA_ID_MOMENT, id)
        }
        setResult(RESULT_OK, saveMomentIntent)
        finish()
    }



    companion object {

        const val EXTRA_DATA_ID_MOMENT = "com.mooth.achieverassistant.moments.idmoment"
        const val EXTRA_DATA_TITLE = "com.mooth.achieverassistant.moments.titlemoment"
        const val EXTRA_DATA_DATE = "com.mooth.achieverassistant.moments.datemoment"
        const val EXTRA_DATA_IMAGE_MOMENT = "com.mooth.achieverassistant.moments.imagemoment"
        const val EXTRA_DATA_SHORT_DESCRIPTION_MOMENT =
            "com.mooth.achieverassistant.moments.shortdesciption"
    }
}

