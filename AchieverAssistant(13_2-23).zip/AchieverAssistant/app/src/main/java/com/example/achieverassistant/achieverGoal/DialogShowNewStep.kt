package com.example.achieverassistant.achieverGoal

import android.app.AlertDialog
import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatDialog
import androidx.appcompat.app.AppCompatDialogFragment
import androidx.lifecycle.ViewModelProvider
import com.example.achieverassistant.R

class DialogShowNewStep : AppCompatDialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        val application = requireActivity().application
        val database = getAchieverGoalsDatabase(application)
        val factory = AchieverGoalViewModel.Factory(database, application)
        val achieverGoalViewModel = ViewModelProvider(this, factory)[AchieverGoalViewModel::class.java]


        val builder = AlertDialog.Builder(activity)
        val layoutInflater = requireActivity().layoutInflater
        val view = layoutInflater.inflate(R.layout.dialog_newstep,null)

        val editText = view.findViewById<EditText>(R.id.edittext_newstep)
        val newStep = editText.text.toString()


        builder.setView(view).setTitle("Add New Step")
            .setNegativeButton("Cancel",DialogInterface.OnClickListener { dialog, which ->
                dismiss()
            })
            .setPositiveButton("Add", DialogInterface.OnClickListener{dialog, which ->
                Toast.makeText(requireActivity(),"ok",Toast.LENGTH_SHORT).show()
            })



        return builder.create()
    }

}