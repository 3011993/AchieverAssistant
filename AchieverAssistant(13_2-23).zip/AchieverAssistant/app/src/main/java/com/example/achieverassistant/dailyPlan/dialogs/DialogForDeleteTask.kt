package com.example.achieverassistant.dailyPlan.dialogs

import android.app.AlertDialog
import android.app.Application
import android.app.Dialog
import android.os.Bundle
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.ViewModelProvider
import com.example.achieverassistant.dailyPlan.DailyTasksLiveModel
import com.example.achieverassistant.dailyPlan.getDatabaseDailyDatabase

class DialogForDeleteTask : DialogFragment() {


    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        val application = requireActivity().application
        val database = getDatabaseDailyDatabase(application)
        val factory = DailyTasksLiveModel.DailyTasksFactory(database, application)
        val dailyTasksViewModel = ViewModelProvider(this, factory)[DailyTasksLiveModel::class.java]

        val alert = AlertDialog.Builder(activity)
        alert.setMessage("are you sure to delete this task?")
        alert.setCancelable(true)
        alert.setTitle("Delete your task")
        alert.setPositiveButton("yes") { dialog, which ->
            //here to delete task
            //dailyTasksLiveModel.cancelAlarm()
            Toast.makeText(activity, "Task is Deleted", Toast.LENGTH_SHORT).show()
        }
        alert.setNegativeButton("No") { dialog, which ->
            dialog.cancel()
            Toast.makeText(activity, "Task is Not Deleted", Toast.LENGTH_SHORT).show()
            //here to observe daily tasks
        }
        return  alert.create()
            }
}