package com.example.achieverassistant.achieverGoal

import android.content.Context

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.Room

@Database(entities = [AchieverGoal::class], version = 3, exportSchema = false)
abstract class AchieverGoalDatabase : RoomDatabase() {
    //this too important to understand it

    abstract fun achieverGoalDAO(): AchieverGoalDAO

   }
private lateinit var INSTANCE : AchieverGoalDatabase


fun getAchieverGoalsDatabase(context: Context) : AchieverGoalDatabase{
    synchronized(AchieverGoalDatabase::class){
        if (!::INSTANCE.isInitialized){
            INSTANCE = Room.databaseBuilder(context.applicationContext,
                AchieverGoalDatabase::class.java,"achieverGoalDatabase").
            fallbackToDestructiveMigration().build()
        }
    }
    return INSTANCE
}

