package com.example.achieverassistant.dailyPlan

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.achieverassistant.R
import android.content.Intent
import android.app.TimePickerDialog

import android.graphics.drawable.ColorDrawable
import android.widget.Toast
import android.app.AlarmManager
import android.app.PendingIntent
import android.graphics.Color
import android.os.Build

import androidx.databinding.DataBindingUtil
import com.example.achieverassistant.CODE_REQUEST_DAILY_NOTIFICATION_ID
import com.example.achieverassistant.databinding.ActivityAddeditdailyTasksBinding
import java.util.*

class ADDEDITDailyTasks : AppCompatActivity() {

    private lateinit var binding: ActivityAddeditdailyTasksBinding
    //Variables for Edittext and Buttons

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_addeditdaily_tasks)

        binding.buttonSaveDailytask.setOnClickListener { saveDailyTasks() }


        binding.edittextTimeCurenttext.isFocusable = false
        binding.edittextCurenttext.isClickable = true
        binding.edittextTimeCurenttext.setOnClickListener { createCalendar() }

        if (intent.hasExtra(EXTRA_DATA_ID_CURRENT_TASK)) {
            title = "Edit Your Task"
            val currentText = intent.getStringExtra(EXTRA_DATA_CURRENT_TEXT)
            val currentTime = intent.getStringExtra(EXTRA_DATA_TIME_CURRENT_TEXT)
            binding.edittextCurenttext.setText(currentText)
            binding.edittextTimeCurenttext.setText(currentTime)
        } else {
            title = "Add New Task"
        }
    }

    //methods for edit text for time onclickListener
    private fun createCalendar() {
        val c = Calendar.getInstance()
        val hour = c[Calendar.HOUR_OF_DAY]
        val minute = c[Calendar.MINUTE]
        val tP = TimePickerDialog(
            this,
            android.R.style.Holo_Light_ButtonBar_AlertDialog,

            { view, hourOfDay, minute ->
                val c = Calendar.getInstance()
                c[Calendar.HOUR_OF_DAY] = hourOfDay
                c[Calendar.MINUTE] = minute
                c[Calendar.SECOND] = 0
                //this for show am or pm
                val AM_PM: String = if (hourOfDay < 12) {
                    "AM"
                } else {
                    "PM"
                }
                // this for show hours in 12 hours mode
                val hours = if (c[Calendar.HOUR] == 0) "12" else Integer.toString(
                    c[Calendar.HOUR]
                )
                //this is make edittext get the time
                binding.edittextTimeCurenttext.setText("$hours:$minute $AM_PM")
                //this for start alarm
                startAlarm(c)
            },
            hour,
            minute,
            false
        )
        tP.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        tP.show()
    }

    //methods for save data for Button Save onclickListener
    private fun saveDailyTasks() {

        val currentTask = binding.edittextCurenttext.text.toString()
        val timeOfTask = binding.edittextTimeCurenttext.text.toString()
        if (currentTask.trim { it <= ' ' }.isEmpty() or timeOfTask.isEmpty()) {
            Toast.makeText(applicationContext, "please write details of your task!", Toast.LENGTH_LONG).show()
            return
        }
        val saveData = Intent()
        saveData.putExtra(EXTRA_DATA_CURRENT_TEXT, currentTask)
        saveData.putExtra(EXTRA_DATA_TIME_CURRENT_TEXT, timeOfTask)

        //this code for managing ID
        val id = intent.getIntExtra(EXTRA_DATA_ID_CURRENT_TASK, -1)
        if (id != -1) {
            saveData.putExtra(EXTRA_DATA_ID_CURRENT_TASK, id)
        }
        setResult(RESULT_OK, saveData)
        finish()
    }

    //we use this method for make alarm remind the user for his task

    private fun startAlarm(c: Calendar) {
        val alarmManager = this.applicationContext.getSystemService(ALARM_SERVICE) as AlarmManager
        val intent = Intent(this.applicationContext, AlarmReceiver::class.java)
        intent.action = "android.intent.action.NOTIFY"
        val pendingIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.getBroadcast(
                this.applicationContext,
                CODE_REQUEST_DAILY_NOTIFICATION_ID, intent,
                 PendingIntent.FLAG_MUTABLE
            )
        } else {
            PendingIntent.getBroadcast(
                this.applicationContext,
                CODE_REQUEST_DAILY_NOTIFICATION_ID, intent,
                PendingIntent.FLAG_UPDATE_CURRENT
            )
        }
        if (c.before(Calendar.getInstance())) {
            c.add(Calendar.DATE, 1)
        }
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, c.timeInMillis, pendingIntent)
    }


    companion object {
        //Variables For Intent and Save Data
        const val EXTRA_DATA_ID_CURRENT_TASK = "com.mooth.achieverassistant.dailytasks.idtask"
        const val EXTRA_DATA_CURRENT_TEXT = "com.mooth.achieverassistant.dailytasks.currenttext"
        const val EXTRA_DATA_TIME_CURRENT_TEXT = "com.mooth.achieverassistant.dailytasks.timetask"

    }
}