package com.example.achieverassistant.quotes_

import com.example.achieverassistant.quotes_.Quote
import androidx.lifecycle.LiveData
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface QuoteDAO {
    @Insert
     fun insertQuote(quote: Quote)

    @Update
     fun updateQuote(quote: Quote)

    @Delete
     fun deleteQuote(quote: Quote)

    @Query("DELETE FROM Quote")
     fun deleteAllQuotes()

    @Query("SELECT * FROM Quote")
     fun allQuotes(): Flow<List<Quote>>
}