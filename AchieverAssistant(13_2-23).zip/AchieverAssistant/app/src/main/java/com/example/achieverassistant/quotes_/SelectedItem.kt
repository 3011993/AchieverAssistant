package com.example.achieverassistant.quotes_

data class SelectedItem(var member : String ,var avatar : Int)