package com.example.achieverassistant.dailyPlan

import android.app.*
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.lifecycle.*
import com.example.achieverassistant.CODE_REQUEST_DAILY_NOTIFICATION_ID
import com.example.achieverassistant.NOTIFICATION_DAILY_ID
import com.example.achieverassistant.cancelAllNotifications
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class DailyTasksLiveModel(private val database: DailyTasksDatabase,application: Application) :
    AndroidViewModel(application) {



    private val context = getApplication<Application>().applicationContext as Application

    private val _allDailyTasks = MutableLiveData<List<DailyTasks>>()

    val allDailyTasks: LiveData<List<DailyTasks>>
        get() = _allDailyTasks

    init {
        viewModelScope.launch(Dispatchers.IO) {
            getALlDailyTasks()
        }
    }


    fun insertDailyTask(dailyTasks: DailyTasks) {
        viewModelScope.launch(Dispatchers.IO) {
            database.dailyDAO().insert(dailyTasks)
        }

    }

    fun updateDailyTask(dailyTasks: DailyTasks) {
        viewModelScope.launch(Dispatchers.IO) {
            database.dailyDAO().update(dailyTasks)
        }
    }

    fun deleteDailyTask(dailyTasks: DailyTasks) {
        viewModelScope.launch(Dispatchers.IO) {
            database.dailyDAO().delete(dailyTasks)
            newCancelAlarm()
        }

    }

    fun deleteAllDailyTasks() {
        viewModelScope.launch(Dispatchers.IO) {
            database.dailyDAO().deleteAll()

            val notificationManager =
                ContextCompat.getSystemService(context,
                    NotificationManager::class.java) as NotificationManager

            notificationManager.cancel(NOTIFICATION_DAILY_ID)
        }
    }

    private fun getALlDailyTasks() {
        viewModelScope.launch(Dispatchers.IO) {
            database.dailyDAO().getAllTasks().collect() {
                _allDailyTasks.postValue(it)
            }


        }
    }




    //we use it when the user delete task to cancel alarm cause we don't need to remind him for deleted task
    private fun cancelAlarm() {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java)
        val pendingIntent =
            PendingIntent.getBroadcast(context, NOTIFICATION_DAILY_ID, intent, PendingIntent.FLAG_CANCEL_CURRENT)
        alarmManager.cancel(pendingIntent)
    }

    private fun newCancelAlarm(){
        val notificationManager = ContextCompat.getSystemService(context,NotificationManager::class.java) as NotificationManager
        notificationManager.cancel(NOTIFICATION_DAILY_ID)
    }
    fun deleteTaskWithAlert(dailyTasks: DailyTasks){
        val alert = AlertDialog.Builder(context)
        alert.setMessage("are you sure to delete this task?")
        alert.setCancelable(true)
        alert.setTitle("Delete your task")
        alert.setPositiveButton("yes") { dialog, which ->
            deleteDailyTask(dailyTasks)
            Toast.makeText(context, "Task is Deleted", Toast.LENGTH_SHORT).show()
        }
        alert.setNegativeButton("No") { dialog, which ->
            dialog.cancel()
            Toast.makeText(context, "Task is Not Deleted", Toast.LENGTH_SHORT).show()

        }
        val dialog = alert.create()
        dialog.show()
    }








class DailyTasksFactory(val database: DailyTasksDatabase, val app: Application) :
    ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DailyTasksLiveModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return DailyTasksLiveModel(database, app) as T
        }
        throw IllegalArgumentException("Unable to construct ViewModel")
    }
}
    }

