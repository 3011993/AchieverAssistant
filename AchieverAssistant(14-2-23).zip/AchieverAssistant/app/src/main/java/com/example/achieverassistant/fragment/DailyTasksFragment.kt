package com.example.achieverassistant.fragment


import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.example.achieverassistant.dailyPlan.*
import com.example.achieverassistant.R
import com.example.achieverassistant.channelDailyNotificationID
import com.example.achieverassistant.channelDailyNotificationName
import com.example.achieverassistant.dailyPlan.dialogs.DialogForDeleteAllTasks
import com.example.achieverassistant.databinding.DailyTasksLayoutBinding
import com.example.achieverassistant.dailyPlan.DailyTasks as DailyTasks1

class DailyTasksFragment : Fragment() {

    private lateinit var binding: DailyTasksLayoutBinding
    private lateinit var recyclerAdapterForDailyTask: RecyclerViewForDailyPlan


   private lateinit var dailyTasksLiveModel : DailyTasksLiveModel




    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = DataBindingUtil.inflate(inflater, R.layout.daily_tasks_layout, container, false)



        val application = requireActivity().application
        val database = getDatabaseDailyDatabase(application)
        val factory = DailyTasksLiveModel.DailyTasksFactory(database, application)
        dailyTasksLiveModel = ViewModelProvider(this, factory)[DailyTasksLiveModel::class.java]

        val clickListener = RecyclerViewForDailyPlan.OnDailyTasksListener({dailyTask ->
            val data = Intent(activity, ADDEDITDailyTasks::class.java)
            data.putExtra(ADDEDITDailyTasks.EXTRA_DATA_ID_CURRENT_TASK,dailyTask.id)
            data.putExtra(ADDEDITDailyTasks.EXTRA_DATA_CURRENT_TEXT, dailyTask.text_current_text)
            data.putExtra(ADDEDITDailyTasks.EXTRA_DATA_TIME_CURRENT_TEXT, dailyTask.time_current_task)
            editActivityResultLauncher.launch(data)
        },{ id ->

            val alert = AlertDialog.Builder(activity)
            alert.setMessage("are you sure to delete this task?")
            alert.setCancelable(true)
            alert.setTitle("Delete your task")
            alert.setPositiveButton("yes") { dialog, which ->
                dailyTasksLiveModel.deleteDailyTask(id)
                //dailyTasksLiveModel.cancelAlarm()
                Toast.makeText(activity, "Task is Deleted", Toast.LENGTH_SHORT).show()
            }
            alert.setNegativeButton("No") { dialog, which ->
                dialog.cancel()
                Toast.makeText(activity, "Task is Not Deleted", Toast.LENGTH_SHORT).show()
                recyclerAdapterForDailyTask.notifyDataSetChanged()
            }
            val dialog = alert.create()
            dialog.show()
        })

        recyclerAdapterForDailyTask = RecyclerViewForDailyPlan(clickListener)




        binding.recyclerviewforDailytasks.adapter = recyclerAdapterForDailyTask
        binding.lifecycleOwner = this
        binding.dailyViewModel = dailyTasksLiveModel

        dailyTasksLiveModel.allDailyTasks.observe(viewLifecycleOwner) { dailyTasks ->
            recyclerAdapterForDailyTask.submitList(dailyTasks)
        }

        binding.buttonAddNewTask.setOnClickListener {
            val intent = Intent(activity, ADDEDITDailyTasks::class.java)
            addActivityResultLauncher.launch(intent)
        }




        setHasOptionsMenu(true)
        createChannel(channelDailyNotificationID, channelDailyNotificationName)

        return binding.root
    }

    //Delete All Tasks With AlertDialog
    private fun deleteAllTasksWithDialog() {
        val alertDialog = DialogForDeleteAllTasks()
        alertDialog.show(childFragmentManager, "Alert Dialog")
    }

    //Activity Result Launcher Apis
    private val addActivityResultLauncher = registerForActivityResult(
        StartActivityForResult()) { result ->
        if(result.data != null) {
            if (result.resultCode == Activity.RESULT_OK) {
                val currentTask =
                    result.data!!.getStringExtra(ADDEDITDailyTasks.EXTRA_DATA_CURRENT_TEXT).toString()
                val timeTask =
                    result.data!!.getStringExtra(ADDEDITDailyTasks.EXTRA_DATA_TIME_CURRENT_TEXT).toString()
                val dailyTasks = DailyTasks1(currentTask, timeTask)
                dailyTasksLiveModel.insertDailyTask(dailyTasks)
                Toast.makeText(requireActivity(), "Task Added", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireActivity(), "DailyTask Not Added", Toast.LENGTH_SHORT).show()
            }
        }
    }

     private val editActivityResultLauncher = registerForActivityResult(StartActivityForResult()){ result ->
        if(result.data != null){
            if (result.resultCode == Activity.RESULT_OK){

                val id = result.data!!.getIntExtra(ADDEDITDailyTasks.EXTRA_DATA_ID_CURRENT_TASK, -1)
                if (id == -1) {
                    Toast.makeText(activity, "Task not edited", Toast.LENGTH_SHORT).show()
                }
                val currentTask =
                    result.data!!.getStringExtra(ADDEDITDailyTasks.EXTRA_DATA_CURRENT_TEXT).toString()
                val timeOfTask =
                    result.data!!.getStringExtra(ADDEDITDailyTasks.EXTRA_DATA_TIME_CURRENT_TEXT).toString()
                val dailyTasks = DailyTasks1(currentTask, timeOfTask)
                dailyTasks.id = id
                dailyTasksLiveModel.updateDailyTask(dailyTasks)
                Toast.makeText(activity, "Task Edited", Toast.LENGTH_SHORT).show()
            }else {
                Toast.makeText(activity, "DailyTask Not Edited", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.daily_tasks_menu, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.deleteAllTasks -> deleteAllTasksWithDialog()
        }
        return super.onOptionsItemSelected(item)

    }
    private fun createChannel(channelId: String, channelName: String) {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){

            val notificationChannel =
                NotificationChannel(channelId,channelName,NotificationManager.IMPORTANCE_HIGH).
                apply { setShowBadge(false) }

            notificationChannel.enableLights(true)
            notificationChannel.lightColor = Color.RED
            notificationChannel.enableVibration(true)
            notificationChannel.description = "Time For Do your task!"
            val notificationManager = requireActivity().getSystemService(NotificationManager::class.java) as NotificationManager
            notificationManager.createNotificationChannel(notificationChannel)

        }
    }
}