package com.example.achieverassistant.quotes

data class SelectedItem(var member : String ,var avatar : Int)