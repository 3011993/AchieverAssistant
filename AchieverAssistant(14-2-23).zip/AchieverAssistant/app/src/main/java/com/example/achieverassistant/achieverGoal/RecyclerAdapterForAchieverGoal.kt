package com.example.achieverassistant.achieverGoal


import android.app.AlertDialog
import android.view.ViewGroup
import android.view.LayoutInflater
import android.content.Intent
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import com.example.achieverassistant.R
import com.example.achieverassistant.databinding.CardviewLifegoalBinding

class RecyclerAdapterForAchieverGoal() :
    ListAdapter<AchieverGoal, RecyclerAdapterForAchieverGoal.ViewHolder>(
        DiffCallBack
    ) {

    private lateinit var listener: OnAchieverGoalListener

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolder {
        return ViewHolder.from(viewGroup)
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val achieverGoal = getItem(position)
        holder.bind(achieverGoal)
    }


    fun getItemAt(position: Int): AchieverGoal {
        return getItem(position)
    }


    class ViewHolder(private val binding: CardviewLifegoalBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(achieverGoal: AchieverGoal) {

            binding.achieverGoal = achieverGoal
            binding.executePendingBindings()

            binding.addStepImageButton.setOnClickListener {
                val dialog = DialogShowNewStep()
                val manager = (itemView.context as AppCompatActivity).supportFragmentManager
                dialog.show(manager, "dialog")
                Log.i("dialog", "opened")
            }

            binding.imageviewEditgoal.setOnClickListener {
                val intent = Intent(itemView.context, AddEditGoal::class.java)
                intent.putExtra(AddEditGoal.EXTRA_DATA_ID_GOAL, achieverGoal.achiever_goal_id)
                intent.putExtra(AddEditGoal.EXTRA_DATA_GOAL, achieverGoal.achiever_goal)
                intent.putExtra(
                    AddEditGoal.EXTRA_DATA_DURATION_GOAl,
                    achieverGoal.achiever_goal_duration
                )
                intent.putExtra(AddEditGoal.EXTRA_DATA_STEP_GOAl, achieverGoal.achiever_goal_steps)
                itemView.context.startActivity(intent)
            }
        }


        companion object {
            fun from(viewGroup: ViewGroup): ViewHolder {
                val layoutInflater = LayoutInflater.from(viewGroup.context)
                val binding = CardviewLifegoalBinding.inflate(layoutInflater, viewGroup, false)
                return ViewHolder(binding)
            }


        }


    }

    companion object {
        private val DiffCallBack: DiffUtil.ItemCallback<AchieverGoal> =
            object : DiffUtil.ItemCallback<AchieverGoal>() {
                override fun areItemsTheSame(
                    oldgoal: AchieverGoal,
                    newgoal: AchieverGoal
                ): Boolean {
                    return oldgoal.achiever_goal_id == newgoal.achiever_goal_id
                }

                override fun areContentsTheSame(
                    oldgoal: AchieverGoal,
                    newgoal: AchieverGoal
                ): Boolean {
                    return oldgoal.achiever_goal == newgoal.achiever_goal && oldgoal.achiever_goal_duration == newgoal.achiever_goal_duration && oldgoal.achiever_goal_steps == newgoal.achiever_goal_steps
                }
            }


    }

    interface OnAchieverGoalListener {
        fun setOnAchieverGoalListener(achieverGoal: AchieverGoal)
    }

    fun setonAchieverClickedListener(listener: OnAchieverGoalListener) {
        this.listener = listener
    }


}