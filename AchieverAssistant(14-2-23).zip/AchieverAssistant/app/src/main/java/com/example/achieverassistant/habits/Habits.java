package com.example.achieverassistant.habits;


import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.achieverassistant.R;

public class Habits extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_habits);
    }
}