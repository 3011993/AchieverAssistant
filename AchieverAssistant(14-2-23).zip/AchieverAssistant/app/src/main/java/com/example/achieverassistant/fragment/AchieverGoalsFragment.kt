package com.example.achieverassistant.fragment


import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.Application
import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.example.achieverassistant.R
import com.example.achieverassistant.achieverGoal.*
import com.example.achieverassistant.databinding.AchieverGoalsLayoutBinding

class AchieverGoalsFragment : Fragment() {


    lateinit var recyclerAdapterForAchieverGoal: RecyclerAdapterForAchieverGoal
    private lateinit var binding: AchieverGoalsLayoutBinding
    private lateinit var achieverGoalViewModel : AchieverGoalViewModel


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding =
            DataBindingUtil.inflate(inflater, R.layout.achiever_goals_layout, container, false)

        val application = requireNotNull(this.activity).application
        val database = getAchieverGoalsDatabase(application)
        val factory = AchieverGoalViewModel.Factory(database,application)
         achieverGoalViewModel =
            ViewModelProvider(this, factory)[AchieverGoalViewModel::class.java]





        binding.buttonAddNewGoal.setOnClickListener {
            val intent = Intent(activity, AddEditGoal::class.java)
            activityResultLauncher.launch(intent)
        }


        recyclerAdapterForAchieverGoal = RecyclerAdapterForAchieverGoal()

        binding.recyclerAchieverGoal.adapter = recyclerAdapterForAchieverGoal
        binding.lifecycleOwner = this
        binding.viewModel = achieverGoalViewModel

        achieverGoalViewModel.achieverGoals.observe(viewLifecycleOwner) {
            recyclerAdapterForAchieverGoal.submitList(it)
        }




        recyclerAdapterForAchieverGoal.setonAchieverClickedListener(object :
            RecyclerAdapterForAchieverGoal.OnAchieverGoalListener {
            override fun setOnAchieverGoalListener(achieverGoal: AchieverGoal) {
                val intent = Intent(activity, AddEditGoal::class.java)
                intent.putExtra(getString(R.string.requestCodeAchiever), edit_goal_request)
                intent.putExtra(AddEditGoal.EXTRA_DATA_ID_GOAL, achieverGoal.achiever_goal_id)
                intent.putExtra(AddEditGoal.EXTRA_DATA_GOAL, achieverGoal.achiever_goal)
                intent.putExtra(
                    AddEditGoal.EXTRA_DATA_DURATION_GOAl,
                    achieverGoal.achiever_goal_duration
                )
                intent.putExtra(AddEditGoal.EXTRA_DATA_STEP_GOAl, achieverGoal.achiever_goal_steps)
                editActivityLauncher.launch(intent)
            }
        })


        ItemTouchHelper(object :
            ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                viewHolder1: RecyclerView.ViewHolder
            ): Boolean {
                return false
            }


            @SuppressLint("NotifyDataSetChanged")
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, i: Int) {
                val alert = AlertDialog.Builder(activity)
                alert.setMessage("are you sure to delete this Goal?")
                alert.setCancelable(true)
                alert.setTitle("Delete your Goal")
                alert.setPositiveButton("yes") { dialog, which ->
                    recyclerAdapterForAchieverGoal.getItemAt(
                        viewHolder.bindingAdapterPosition
                    )?.let {
                        achieverGoalViewModel.deleteGoal(
                            it
                        )
                    }
                    Toast.makeText(activity, "Goal is Deleted", Toast.LENGTH_SHORT).show()
                }
                //first  issue when use click on the task is deleted also
                alert.setNegativeButton("No") { dialog, which ->
                    dialog.cancel()
                    Toast.makeText(activity, "Task is Not Deleted", Toast.LENGTH_SHORT).show()
                    achieverGoalViewModel.achieverGoals.observe(viewLifecycleOwner,
                        Observer { achieverGoals ->
                            recyclerAdapterForAchieverGoal!!.submitList(achieverGoals)
                            recyclerAdapterForAchieverGoal!!.notifyDataSetChanged()
                        })
                }

                val dialog = alert.create()
                dialog.show()
            }
        }).attachToRecyclerView(binding.recyclerAchieverGoal)

        setHasOptionsMenu(true)

        return binding.root
    }


    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.achiever_goal_menu,menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.deleteAllGoals -> {
                achieverGoalViewModel.deleteAllGoals()
            }
        }
        return super.onOptionsItemSelected(item)

    }

    private var activityResultLauncher =
        registerForActivityResult(StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == Activity.RESULT_OK) {
                val goal = data!!.getStringExtra(AddEditGoal.EXTRA_DATA_GOAL).toString()
                val durationgoal =
                    data.getStringExtra(AddEditGoal.EXTRA_DATA_DURATION_GOAl).toString()
                val stepgoal = data.getStringExtra(AddEditGoal.EXTRA_DATA_STEP_GOAl).toString()
                val achieverGoal = AchieverGoal(
                    achiever_goal = goal,
                    achiever_goal_duration = durationgoal,
                    achiever_goal_steps = stepgoal
                )
                achieverGoalViewModel!!.insertGoal(achieverGoal)
                Toast.makeText(activity, "Goal Added", Toast.LENGTH_SHORT).show()
            }
        }


    var editActivityLauncher = registerForActivityResult(
        StartActivityForResult()
    ) { result ->
        val data = result.data
        val requestGoalEdit = result.data!!
            .getIntExtra(getString(R.string.requestCodeAchiever), edit_goal_request)
        if (result.resultCode == requestGoalEdit && result.resultCode == Activity.RESULT_OK) {
            val id = data!!.getIntExtra(AddEditGoal.EXTRA_DATA_ID_GOAL, -1)
            if (id == -1) {
                Toast.makeText(activity, "Goal Not Added", Toast.LENGTH_SHORT).show()
            }
            val goal = data.getStringExtra(AddEditGoal.EXTRA_DATA_GOAL).toString()
            val durationGoal = data.getStringExtra(AddEditGoal.EXTRA_DATA_DURATION_GOAl).toString()
            val stepGoal = data.getStringExtra(AddEditGoal.EXTRA_DATA_STEP_GOAl).toString()
            val achieverGoal = AchieverGoal(
                achiever_goal = goal,
                achiever_goal_duration = durationGoal,
                achiever_goal_steps = stepGoal
            )
            achieverGoal.achiever_goal_id = id
            achieverGoalViewModel.updateGoal(achieverGoal)
            Toast.makeText(activity, "Goal Edited", Toast.LENGTH_SHORT).show()
        }
    }

//    inner class ItemTouchHelperObject(val application: Application) : ItemTouchHelper.SimpleCallback(0,ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT) {
//        override fun onMove(
//            recyclerView: RecyclerView,
//            viewHolder: RecyclerView.ViewHolder,
//            target: RecyclerView.ViewHolder
//        ): Boolean {
//            return false
//        }

//        override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
//            val dialog = DialogRemoveGoal()
//            dialog.show(childFragmentManager,"Delete Goal")
//            val alert = AlertDialog.Builder(application)
//            alert.setMessage("are you sure to delete this Goal?")
//            alert.setCancelable(true)
//            alert.setTitle("Delete your Goal")
//            alert.setPositiveButton("yes") { dialog, which ->
//                viewHolder.bindingAdapterPosition
//                    .let {
//                    achieverGoalViewModel.deleteGoal( it)
//                }
//                Toast.makeText(application, "Goal is Deleted", Toast.LENGTH_SHORT).show()
//            }
//            //first  issue when use click on the task is deleted also
//            alert.setNegativeButton("No") { dialog, which ->
//                dialog.cancel()
//                Toast.makeText(application, "Task is Not Deleted", Toast.LENGTH_SHORT).show()
//                   }
//
//
//            val dialog = Dialog(application)
//            dialog.show()
//        }
//
//    }



    companion object {
        const val success_goal_request = 11
        const val edit_goal_request = 22
    }
}