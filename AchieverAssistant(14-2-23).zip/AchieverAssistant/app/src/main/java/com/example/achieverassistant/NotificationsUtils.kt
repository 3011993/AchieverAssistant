package com.example.achieverassistant

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.example.achieverassistant.dailyPlan.ActionReceiver

const val channelDailyNotificationID = "Daily Task Notification ID"
const val channelDailyNotificationName = "Daily Task Notifications"
const val CODE_REQUEST_DAILY_NOTIFICATION_ID =202
const val NOTIFICATION_DAILY_ID = 77


fun NotificationManager.sendNotification(context: Context){

    val actionIntent = Intent(context, ActionReceiver::class.java)
    val actionPending = PendingIntent.getBroadcast(context,88,actionIntent,PendingIntent.FLAG_IMMUTABLE)

    val intent = Intent(context,MainActivity::class.java)
    val contentIntent =
        PendingIntent.getActivity(context, NOTIFICATION_DAILY_ID,intent, PendingIntent.FLAG_IMMUTABLE)

    val builder = NotificationCompat.Builder(context, channelDailyNotificationID)
        .setContentTitle("Achiever!")
        .setContentText("Here We are Go ;)")
        .setSmallIcon(R.drawable.ic_favorite_border_black_24dp)
        .setAutoCancel(true)
        .setContentIntent(contentIntent)
        .addAction(R.drawable.ic_baseline_done_24,"task completed!",actionPending)
        .setPriority(NotificationCompat.PRIORITY_HIGH)


    notify(NOTIFICATION_DAILY_ID,builder.build())


}

fun NotificationManager.cancelAllNotifications(){
    cancelAll()
}