package com.example.achieverassistant.moments

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "moments_table")
class TheMoment(var image: String, var title: String, var date: String, var descripton: String) {
    @PrimaryKey(autoGenerate = true)
    var id = 0

}