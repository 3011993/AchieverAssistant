package com.example.achieverassistant.moments

import android.view.ViewGroup
import android.view.LayoutInflater
import android.graphics.BitmapFactory
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import com.example.achieverassistant.databinding.CardviewMomentsBinding

class RecyclerAdapterForMoments(private val clickListener: OnMomentListener) :
    ListAdapter<TheMoment,RecyclerAdapterForMoments.ViewHolderMoment>(diffCallBack ) {

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolderMoment {
        return ViewHolderMoment.from(viewGroup)
    }

     override fun onBindViewHolder(viewHolderMoment: ViewHolderMoment, position: Int) {
         val theMoment = getItem(position)
         viewHolderMoment.bind(clickListener,theMoment)
     }



     class ViewHolderMoment(private val binding: CardviewMomentsBinding) : RecyclerView.ViewHolder(binding.root) {


         fun bind(clickListener: OnMomentListener,theMoment: TheMoment) {
             binding.textviewTitle.text = theMoment.title
             binding.textviewDate.text = theMoment.date
             binding.shortdescriptionMoment.text = theMoment.descripton
             val myBitmap = BitmapFactory.decodeFile(theMoment.image)
             binding.imageviewMoment.setImageBitmap(myBitmap)
             binding.moment = theMoment
             binding.clickListener = clickListener
             binding.executePendingBindings()
         }


        companion object {
            fun from(viewGroup: ViewGroup): ViewHolderMoment {
                val layoutInflater = LayoutInflater.from(viewGroup.context)
                val binding = CardviewMomentsBinding.inflate(layoutInflater, viewGroup, false)
                return ViewHolderMoment(binding)
            }
        }
    }

    fun getItemAt(position: Int): TheMoment? {
        return getItem(position)
    }

     class OnMomentListener(val clickListener: (theMoment: TheMoment) -> Unit) {
        fun onClick(theMoment: TheMoment) = clickListener(theMoment)
    }

    companion object {
        private val diffCallBack: DiffUtil.ItemCallback<TheMoment> =
            object : DiffUtil.ItemCallback<TheMoment>() {
                override fun areItemsTheSame(oldmoment: TheMoment, newmoment: TheMoment): Boolean {
                    return oldmoment.id == newmoment.id
                }

                override fun areContentsTheSame(
                    oldmoment: TheMoment,
                    newmoment: TheMoment
                ): Boolean {
                    return oldmoment.image == newmoment.image && oldmoment.title == newmoment.title && oldmoment.descripton == newmoment.descripton && oldmoment.date == newmoment.date
                }
            }
    }

}