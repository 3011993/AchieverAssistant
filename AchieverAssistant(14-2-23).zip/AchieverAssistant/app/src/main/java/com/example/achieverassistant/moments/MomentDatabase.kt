package com.example.achieverassistant.moments

import android.content.Context
import androidx.room.Database
import androidx.room.RoomDatabase

import androidx.room.Room

@Database(entities = [TheMoment::class], version = 2, exportSchema = false)
abstract class MomentDatabase : RoomDatabase() {
    abstract fun momentDAO(): MomentDAO

    }

private lateinit var INSTANCE : MomentDatabase

fun getMomentsDatabase(context: Context) : MomentDatabase {
    synchronized(MomentDatabase::class.java) {
        if (!::INSTANCE.isInitialized) {
            INSTANCE =
                Room.databaseBuilder(
                    context.applicationContext,
                    MomentDatabase::class.java,
                    "MomentsDatabase"
                ).fallbackToDestructiveMigration().build()
        }
        return INSTANCE
    }
}





