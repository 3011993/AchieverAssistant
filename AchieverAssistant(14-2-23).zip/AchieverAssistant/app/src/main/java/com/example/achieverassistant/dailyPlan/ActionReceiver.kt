package com.example.achieverassistant.dailyPlan

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        val completedIntent = Intent(context,DailyTasks::class.java)
        context!!.startActivity(completedIntent)
        Toast.makeText(context,"Good Job!",Toast.LENGTH_SHORT).show()

    }
}