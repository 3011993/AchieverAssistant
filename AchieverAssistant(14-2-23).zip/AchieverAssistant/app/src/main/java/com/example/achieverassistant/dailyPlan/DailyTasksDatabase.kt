package com.example.achieverassistant.dailyPlan

import android.content.Context
import androidx.room.Database
import androidx.room.Room.databaseBuilder
import androidx.room.RoomDatabase

@Database(entities = [DailyTasks::class], version = 2, exportSchema = false)
abstract class DailyTasksDatabase : RoomDatabase() {

    abstract fun dailyDAO(): DailyDAO

    }

private lateinit var INSTANCE : DailyTasksDatabase


fun getDatabaseDailyDatabase(context: Context) : DailyTasksDatabase {
    synchronized(DailyTasksDatabase::class){
        if (!::INSTANCE.isInitialized){
            INSTANCE = databaseBuilder(context.applicationContext,
                DailyTasksDatabase::class.java,"dailyTasksDatabase").
            fallbackToDestructiveMigration().build()
        }
    }
    return INSTANCE
}

