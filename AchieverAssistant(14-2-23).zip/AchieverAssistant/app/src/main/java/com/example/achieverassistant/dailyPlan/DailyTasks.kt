package com.example.achieverassistant.dailyPlan

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class DailyTasks(var text_current_text: String, var time_current_task: String) {
    @PrimaryKey(autoGenerate = true)
    var id = 0




}