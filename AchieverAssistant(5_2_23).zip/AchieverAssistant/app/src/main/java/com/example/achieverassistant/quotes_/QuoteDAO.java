package com.example.achieverassistant.quotes_;


import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface QuoteDAO {

    @Insert
    void insertQuote(Quote quote);
    @Update
    void updateQuote(Quote quote);
    @Delete
    void deleteQuote(Quote quote);
    @Query("DELETE FROM QUOTE")
    void deleteAllQuotes();
    @Query("SELECT * FROM Quote")
    LiveData<List<Quote>> getAllQuotes();

}




