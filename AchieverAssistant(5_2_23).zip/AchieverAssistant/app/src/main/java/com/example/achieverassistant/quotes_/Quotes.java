package com.example.achieverassistant.quotes_;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;

import androidx.lifecycle.ViewModelProviders;
import android.content.Intent;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import android.view.View;
import android.widget.Toast;

import com.example.achieverassistant.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

import static com.example.achieverassistant.quotes_.ADDEDITQuote.EXTRA_DATA_MEMBERQUOTE;
import static com.example.achieverassistant.quotes_.ADDEDITQuote.EXTRA_DATA_QUOTE;

public class Quotes extends AppCompatActivity {

    RecyclerView recyclerView;
    RecyclerAdapterForQuotes adapterForQuotes;

    FloatingActionButton button_addquote;


    QuoteLiveData quoteLiveData;
    private  final static int REQUEST_SAVE_QUOTE = 22513;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quotes);



        quoteLiveData = ViewModelProviders.of(this).get(QuoteLiveData.class);
        quoteLiveData.getAllQuotes().observe(this, new Observer<List<Quote>>() {
            @Override
            public void onChanged(@Nullable List<Quote> quotes) {
                adapterForQuotes.submitList(quotes);
            }
        });









        button_addquote = findViewById(R.id.button_addquote);
        button_addquote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Quotes.this,ADDEDITQuote.class);
                startActivityForResult(intent,REQUEST_SAVE_QUOTE);

            }
        });

        recyclerView = findViewById(R.id.recycler_quotes);
        adapterForQuotes = new RecyclerAdapterForQuotes();


        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapterForQuotes);


    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQUEST_SAVE_QUOTE && resultCode == RESULT_OK ){

            String QuoteMember = data.getStringExtra(EXTRA_DATA_MEMBERQUOTE);
            String Quote = data.getStringExtra(EXTRA_DATA_QUOTE);


            Quote quote = new Quote(QuoteMember,Quote);
            quoteLiveData.insertQuote(quote);
            Toast.makeText(this,"Don't Forget their Words",Toast.LENGTH_SHORT).show();
        }
        if (requestCode == REQUEST_SAVE_QUOTE&& resultCode == RESULT_CANCELED){
            Toast.makeText(this,"there no add fo moment",Toast.LENGTH_SHORT).show();
        }
    }
}
