package com.example.achieverassistant.achieverGoal


import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Entity
@Parcelize
data class AchieverGoal(
    @PrimaryKey(autoGenerate = true) var achiever_goal_id: Int = 0,
    var achiever_goal: String,
    var achiever_goal_duration: String,
    var achiever_goal_steps: String,
    ) : Parcelable




