package com.example.achieverassistant.moments

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.icu.text.SimpleDateFormat
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.achieverassistant.R
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.io.File
import java.util.*

class Moments : AppCompatActivity() {

    lateinit var currentImagePath: String
    lateinit var pathToFile: String
    lateinit var momentsViewModel: MomentsViewModel
    lateinit var recyclerAdapterForMoments: RecyclerAdapterForMoments
    lateinit var recyclerView: RecyclerView


    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_moments)



        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(
                arrayOf(
                    Manifest.permission.CAMERA,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                ), CODE_REQUEST_PERMISSION_CAMERA
            )
        }


        val database = getMomentsDatabase(application.applicationContext)
        val factory = MomentsViewModel.MomentsFactory(database, application)
        momentsViewModel = ViewModelProvider(this, factory)[MomentsViewModel::class.java]



        recyclerAdapterForMoments = RecyclerAdapterForMoments()
        recyclerView = findViewById(R.id.recyclerview_moments)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)
        recyclerView.adapter = recyclerAdapterForMoments
        momentsViewModel.allMoments.observe(this) { theMoments ->
            recyclerAdapterForMoments.submitList(
                theMoments
            )
        }
        val capture = findViewById<FloatingActionButton>(R.id.capture_moment)
        capture.setOnClickListener { captureMoment() }
    }

    //this responsible for take shot and save everything
    @RequiresApi(Build.VERSION_CODES.N)
    private fun captureMoment() {

        var photofile: File?
        photofile = createPhotoFile()

        if (photofile != null) {
            pathToFile = photofile.absolutePath
            val photoURL = FileProvider.getUriForFile(
                this,
                "com.example.camera_pictures.fileprovider",
                photofile
            )
            //takePic.putExtra(MediaStore.EXTRA_OUTPUT, photoURL)
            getCameraImage.launch(photoURL)
        }

    }

    //this method for save picture
    @RequiresApi(Build.VERSION_CODES.N)
    private fun createPhotoFile(): File {
        val timestamp = SimpleDateFormat("yyyyMMDD_HHmmss").format(Date())
        val imageDirectory =
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
        var file: File? = null
        try {
            file = File.createTempFile(timestamp, ".jpg", imageDirectory)
            currentImagePath = file.absolutePath
        } catch (e: Exception) {
            Log.e(TAG_MOMENTS, e.message.toString())
        }

        return file!!
    }


    companion object {

        const val EXTRA_PICTURE_PATH = "com.mooth.takenpicture"
        const val CODE_REQUEST_PERMISSION_CAMERA = 55
        const val TAG_MOMENTS = "Moments Tag"


    }


    private val getCameraImage =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success == true) {
                val intent = Intent(this, ADDEDITMoment::class.java)
                intent.putExtra(EXTRA_PICTURE_PATH, pathToFile)
                saveMomentDetails.launch(intent)


                Log.i("intent image", "handle work")
            } else {
                Log.i("intent image", "can't handle work")
            }

        }


    private val saveMomentDetails =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->

            if (result.data != null) {
                if (result.resultCode == Activity.RESULT_OK) {
                    val imageOfMoment =
                        result.data!!.getStringExtra(ADDEDITMoment.EXTRA_DATA_IMAGE_MOMENT)
                            .toString()
                    val titleOfMoment =
                        result.data!!.getStringExtra(ADDEDITMoment.EXTRA_DATA_TITLE).toString()
                    val dateOfMoment =
                        result.data!!.getStringExtra(ADDEDITMoment.EXTRA_DATA_DATE).toString()
                    val shortDescription =
                        result.data!!.getStringExtra(ADDEDITMoment.EXTRA_DATA_SHORT_DESCRIPTION_MOMENT)
                            .toString()
                    momentsViewModel.insertMoment(
                        TheMoment(
                            imageOfMoment,
                            titleOfMoment,
                            dateOfMoment,
                            shortDescription
                        )
                    )
                    Toast.makeText(this, "Your Moment is Great", Toast.LENGTH_SHORT).show()
                    Log.i("intent image", "save intent worked")

                } else {
                    Toast.makeText(this,"Your Moment wasn't added",Toast.LENGTH_SHORT).show()
                    Log.i("intent image", "save intent can't work")

                }

            }


        }

}

//      @RequiresApi(Build.VERSION_CODES.M)
//      fun requestPermissionsForCamera(){
//          if(checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED){
//              Toast.makeText(this,"Permission For Camera Granted",Toast.LENGTH_SHORT).show()
//          } else{
//              requestPermissions(arrayOf (Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE), CODE_REQUEST_PERMISSION_CAMERA)
//              //preferred change it with snackBar with action
//              Toast.makeText(this,"Permission for Camera was denied",Toast.LENGTH_SHORT).show()
//          }
//      }
//}