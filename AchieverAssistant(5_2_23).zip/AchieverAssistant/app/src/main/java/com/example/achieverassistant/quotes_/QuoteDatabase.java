package com.example.achieverassistant.quotes_;


import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import android.content.Context;
import android.os.AsyncTask;
import androidx.annotation.NonNull;

@Database(entities = Quote.class,version = 3 ,exportSchema = false)
public abstract class QuoteDatabase extends RoomDatabase {



    private static QuoteDatabase instance;
    //this too important to understand it
    public abstract QuoteDAO QuoteDAO();

    public static synchronized QuoteDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder
                    (context.getApplicationContext(), QuoteDatabase.class, "quotes_database")
                    .fallbackToDestructiveMigration().addCallback(roomcallback).build();

        }
        return instance;
    }


    private static RoomDatabase.Callback roomcallback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new PopulateDbAsynctask(instance).execute();
        }
    };

    private static class PopulateDbAsynctask extends AsyncTask<Void, Void, Void> {
        private QuoteDAO quoteDAO;

        public PopulateDbAsynctask(QuoteDatabase db) {
            quoteDAO = db.QuoteDAO();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            //momentDAO.insertmoment(new TheMoment("", "my best moment", "23/7/2019","my first application"));
            //momentDAO.insertmoment(new TheMoment("", "one Year From now", "Practice More","best date"));


            return null;
        }


    }
















}
