package com.example.achieverassistant.quotes_;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.achieverassistant.R;


public class RecyclerAdapterForQuotes extends ListAdapter<Quote,RecyclerAdapterForQuotes.ViewHOlder> {


    OnQuoteListener listener ;
    protected RecyclerAdapterForQuotes() {
        super(Diffu_call_back);
    }

    private final static  DiffUtil.ItemCallback<Quote> Diffu_call_back = new DiffUtil.ItemCallback<Quote>() {
        @Override
        public boolean areItemsTheSame(@NonNull Quote oldquote, @NonNull Quote newquote) {
            return oldquote.getQuoteID()== newquote.getQuoteID();
        }

        @Override
        public boolean areContentsTheSame(@NonNull Quote oldquote, @NonNull Quote newquote) {
           return oldquote.getQuote().equals (newquote.getQuote()) &&
                   oldquote.getQuoteMember() .equals(newquote.getQuoteMember());

        }
    };


    @NonNull
    @Override
    public ViewHOlder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemview = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cardview_quotes, viewGroup, false);
        return new ViewHOlder(itemview);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHOlder viewHOlder, int position) {
        Quote quote = getItem(position);
        viewHOlder.quotemember.setText(quote.getQuoteMember());
        viewHOlder.quote.setText(quote.getQuote());

    }

    class ViewHOlder extends RecyclerView.ViewHolder {
        TextView quotemember,quote;
        public ViewHOlder(@NonNull View itemView) {
            super(itemView);
            quotemember = itemView.findViewById(R.id.textview_member);
            quote = itemView.findViewById(R.id.textview_quote);
        }
    }

    public Quote getItemAt(int position){
        return getItem(position);
    }

    public interface OnQuoteListener{
        void setOnQuoteListener(Quote quote);
    }

    public void setOnQuoteClicked(OnQuoteListener listener){
        this.listener = listener;
    }
}
