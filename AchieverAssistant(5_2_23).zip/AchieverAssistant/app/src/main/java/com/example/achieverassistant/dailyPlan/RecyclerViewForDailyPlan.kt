package com.example.achieverassistant.dailyPlan

import android.view.ViewGroup
import android.view.LayoutInflater
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import com.example.achieverassistant.databinding.CardviewForDailyplanBinding

class RecyclerViewForDailyPlan(private val clickListener: DailyTasksListener) : ListAdapter<DailyTasks, RecyclerViewForDailyPlan.DailyViewHolder>(DIFF_CALL_BACK) {


    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): DailyViewHolder {
        return DailyViewHolder.from(viewGroup)
    }

    override fun onBindViewHolder(dailyViewHolder: DailyViewHolder, position: Int) {
        val currentTask = getItem(position)

        dailyViewHolder.bind(clickListener,currentTask)

    }

     class DailyViewHolder(private val binding : CardviewForDailyplanBinding) :
         RecyclerView.ViewHolder(binding.root) {


         fun bind (clickListener: DailyTasksListener, dailyTasks: DailyTasks){
             binding.dailyTask = dailyTasks
             binding.clickListener = clickListener
             binding.textOfCurrenttask.text = dailyTasks.text_current_text
             binding.textOfTimeOfCurrenttask.text = dailyTasks.time_current_task
             binding.executePendingBindings()

         }
        companion object{
            fun from(viewGroup: ViewGroup): DailyViewHolder {
                val layoutInflater = LayoutInflater.from(viewGroup.context)
                val binding = CardviewForDailyplanBinding.inflate(layoutInflater,viewGroup,false)
                return DailyViewHolder(binding)
            }
        }
    }

    fun getItemAt(position: Int): DailyTasks {
        return getItem(position)
    }


    class DailyTasksListener(val clickListener: (dailyTasks: DailyTasks) -> Unit) {
        fun onClick(dailyTasks : DailyTasks ) = clickListener(dailyTasks)

    }

    companion object {
        private val DIFF_CALL_BACK: DiffUtil.ItemCallback<DailyTasks> =
            object : DiffUtil.ItemCallback<DailyTasks>() {
                override fun areItemsTheSame(olditem: DailyTasks, newitem: DailyTasks): Boolean {
                    return olditem.id == newitem.id
                }

                override fun areContentsTheSame(olditem: DailyTasks, newitem: DailyTasks): Boolean {
                    return olditem.text_current_text == newitem.text_current_text && olditem.time_current_task == newitem.time_current_task
                }
            }


    }
}