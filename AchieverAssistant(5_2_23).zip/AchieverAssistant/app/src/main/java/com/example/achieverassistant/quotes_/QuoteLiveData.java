package com.example.achieverassistant.quotes_;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.annotation.NonNull;

import java.util.List;

public class QuoteLiveData extends AndroidViewModel {

    private QuoteRepository quoteRepository;
    private LiveData<List<Quote>> allQuotes;
    public QuoteLiveData(@NonNull Application application) {
        super(application);
        quoteRepository = new QuoteRepository(application);
        allQuotes = quoteRepository.getAllquotes();

    }

    public void insertQuote(Quote quote){
        quoteRepository.insertquote(quote);
    }
    public void deleteQuote(Quote quote){
        quoteRepository.deletetquote(quote);
    }
    public void updateQuote(Quote quote){
        quoteRepository.updatequote(quote);
    }
    public void deleteAllQuotes(){
        quoteRepository.deleteallquotes();

    }
    public LiveData<List<Quote>> getAllQuotes(){
        return allQuotes;
    }



}
