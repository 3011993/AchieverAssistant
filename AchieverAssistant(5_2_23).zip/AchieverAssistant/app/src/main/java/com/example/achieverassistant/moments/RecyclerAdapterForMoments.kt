package com.example.achieverassistant.moments

import android.view.ViewGroup
import android.view.LayoutInflater
import com.example.achieverassistant.R
import android.graphics.BitmapFactory
import android.view.View
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter

class RecyclerAdapterForMoments : ListAdapter<TheMoment,RecyclerAdapterForMoments.ViewHolderMoment>(
    Diffu_call_back )
 {
    lateinit var onMomentListener: OnMomentListener

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolderMoment {
        val itemview = LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.cardview_moments, viewGroup, false)
        return ViewHolderMoment(itemview)
    }


    override fun onBindViewHolder(viewHolderMoment: ViewHolderMoment, position: Int) {
        val theMoment = getItem(position)
        viewHolderMoment.title.text = theMoment.title.toString()
        viewHolderMoment.date.text = theMoment.date.toString()
        viewHolderMoment.shortdescription.text = theMoment.descripton.toString()
        val myBitmap = BitmapFactory.decodeFile(theMoment.image.toString())
        viewHolderMoment.momentimage.setImageBitmap(myBitmap)
    }

    class ViewHolderMoment(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var title: TextView
        var shortdescription: TextView
        var date: TextView
        var momentimage: ImageView

        init {
            title = itemView.findViewById(R.id.textview_title)
            shortdescription = itemView.findViewById(R.id.shortdescription_moment)
            date = itemView.findViewById(R.id.textview_date)
            momentimage = itemView.findViewById(R.id.imageview_moment)
        }
    }

    fun getItemAt(position: Int): TheMoment? {
        return getItem(position)
    }

    interface OnMomentListener {
        fun setOnMomentListener(theMoment: TheMoment?)
    }

    fun setOnMomentClicked(onMomentListener: OnMomentListener?) {
        if (onMomentListener != null) {
            this.onMomentListener = onMomentListener
        }
    }

    companion object {
        private val Diffu_call_back: DiffUtil.ItemCallback<TheMoment> =
            object : DiffUtil.ItemCallback<TheMoment>() {
                override fun areItemsTheSame(oldmoment: TheMoment, newmoment: TheMoment): Boolean {
                    return oldmoment.id == newmoment.id
                }

                override fun areContentsTheSame(
                    oldmoment: TheMoment,
                    newmoment: TheMoment
                ): Boolean {
                    return oldmoment.image == newmoment.image && oldmoment.title == newmoment.title && oldmoment.descripton == newmoment.descripton && oldmoment.date == newmoment.date
                }
            }
    }

}