package com.example.achieverassistant.quotes_;

import android.app.Application;
import androidx.lifecycle.LiveData;
import android.os.AsyncTask;


import java.util.List;

public  class QuoteRepository {



    public LiveData<List<Quote>> allquotes;
    QuoteDAO quoteDAO;


    public QuoteRepository(Application application) {
        QuoteDatabase quoteDatabase = QuoteDatabase.getInstance(application);
        quoteDAO = quoteDatabase.QuoteDAO();
        allquotes = quoteDAO.getAllQuotes();

    }


    public void insertquote(Quote quote) {

        new QuoteRepository.AsyncInsertquote(quoteDAO).execute(quote);
    }

    public void updatequote(Quote quote) {

        new QuoteRepository.AsyncUpdatequote(quoteDAO).execute(quote);
    }

    public void deletetquote(Quote quote) {

        new QuoteRepository.AsyncDeletequote(quoteDAO).execute(quote);
    }

    public void deleteallquotes() {
        new QuoteRepository.AsyncDeleteallquotes(quoteDAO).execute();
    }


    public LiveData<List<Quote>> getAllquotes() {
        return allquotes;
    }


    private static class AsyncInsertquote extends AsyncTask<Quote, Void, Void> {

        QuoteDAO quoteDAO;

        private AsyncInsertquote(QuoteDAO quoteDAO) {
            this.quoteDAO = quoteDAO;
        }

        @Override
        protected Void doInBackground(Quote...quotes) {
            quoteDAO.insertQuote(quotes[0]);
            return null;
        }
    }


    private static class AsyncUpdatequote extends AsyncTask<Quote, Void, Void> {

        QuoteDAO quoteDAO;

        private AsyncUpdatequote(QuoteDAO quoteDAO) {
            this.quoteDAO = quoteDAO;
        }

        @Override
        protected Void doInBackground(Quote... quotes) {
            quoteDAO.updateQuote(quotes[0]);
            return null;
        }
    }


    private static class AsyncDeletequote extends AsyncTask<Quote, Void, Void> {

        QuoteDAO quoteDAO;

        private AsyncDeletequote(QuoteDAO quoteDAO) {
            this.quoteDAO = quoteDAO;
        }

        @Override
        protected Void doInBackground(Quote...quotes) {
            quoteDAO.deleteQuote(quotes[0]);
            return null;
        }
    }


    private static class AsyncDeleteallquotes extends AsyncTask<Void, Void, Void> {
        QuoteDAO quoteDAO;

        private AsyncDeleteallquotes(QuoteDAO quoteDAO) {
            this.quoteDAO = quoteDAO;
        }

        @Override
        protected Void doInBackground(Void... Voids) {
            quoteDAO.deleteAllQuotes();
            return null;
        }
    }













}
