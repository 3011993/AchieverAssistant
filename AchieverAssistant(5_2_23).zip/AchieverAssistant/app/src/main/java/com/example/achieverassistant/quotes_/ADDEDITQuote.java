package com.example.achieverassistant.quotes_;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.achieverassistant.R;

import java.util.ArrayList;

public class ADDEDITQuote extends AppCompatActivity {

    EditText editText_quote;
    Spinner dropdown;
    Button button_record_quote;

    public final  static String EXTRA_DATA_ID_QUOTE = "com.mooth.achieverassistant.quotes.idquote";
    public final static String EXTRA_DATA_MEMBERQUOTE ="com.mooth.achieverassistant.quotes.memberquote";
    public final static String EXTRA_DATA_QUOTE = "com.mooth.achieverassistant.quotes.quote";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addeditquote);

        Intent intent = getIntent();
        if(intent.hasExtra(EXTRA_DATA_ID_QUOTE)){
            setTitle("Remmber Quote");

        }
        else {
            setTitle("Edit this Quote");
        }


         editText_quote= findViewById(R.id.edittext_quote);

        dropdown= findViewById(R.id.spinner);
        ArrayList items = new ArrayList();
        items.add(0,"Select One");
        items.add(1,"Family");
        items.add(2,"Friend");
        items.add(3,"Lover");
        items.add(4,"Anonymous");


        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        dropdown.setAdapter(adapter);

        button_record_quote = findViewById(R.id.button_record_quote);
        button_record_quote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recordQuote();
            }
        });
    }

    private void recordQuote(){

        String quotemember = dropdown.getSelectedItem().toString();
        String Quote = editText_quote.getText().toString();



        if(quotemember.isEmpty() && Quote.isEmpty()){
            Toast.makeText(getApplicationContext(),"Please Select the Member or write the quote",Toast.LENGTH_SHORT).show();
            return;
        }

        Intent save_quote = new Intent();
        save_quote.putExtra(EXTRA_DATA_MEMBERQUOTE,quotemember);
        save_quote.putExtra(EXTRA_DATA_QUOTE,Quote);


        int id = getIntent().getIntExtra(EXTRA_DATA_ID_QUOTE, -1);
        if (id != -1) {
            save_quote.putExtra(EXTRA_DATA_ID_QUOTE, id);
        }

        setResult(RESULT_OK,save_quote);
        finish();









    }
}
