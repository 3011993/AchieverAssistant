package com.example.achieverassistant.quotes_

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
class Quote(var quoteMember: String, var quote: String) {
    @PrimaryKey(autoGenerate = true)
    var quoteID = 0
}