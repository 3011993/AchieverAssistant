package com.example.achieverassistant.achieverGoal

import android.app.AlertDialog
import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.appcompat.app.AppCompatDialog
import androidx.appcompat.app.AppCompatDialogFragment
import com.example.achieverassistant.R

class DialogShowNewStep : AppCompatDialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        val builder = AlertDialog.Builder(activity)
        val layoutInflater = requireActivity().layoutInflater
        val view = layoutInflater.inflate(R.layout.dialog_newstep,null)

        val editText = view.findViewById<EditText>(R.id.edittext_newstep)
        val newStep = editText.text.toString()

        builder.setView(view).setTitle("Add New Step")
            .setNegativeButton("Cancel",DialogInterface.OnClickListener { dialog, which ->

            })
            .setPositiveButton("Add", DialogInterface.OnClickListener{dialog, which ->

            })



        return builder.create()
    }

}